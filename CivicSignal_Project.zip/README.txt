CivicSignal - IBM Z Datathon project package

Open CivicSignal.html in a current browser to explore the interface. The prototype uses synthetic sample complaints and browser local storage. See CIVIC-AI-README.md for run instructions, behavior, limitations, privacy notes, and proposed IBM LinuxONE/Db2 integration. No IBM Z or LinuxONE service is connected in this prototype.
