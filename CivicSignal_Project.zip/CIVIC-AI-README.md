# CivicSignal public-service prototype

This is a browser-only demonstration of the problem and solution described in the IBM Z Datathon Civic AI concept. It represents community reports such as water interruptions, road damage, garbage, drainage, street lighting, transit, safety, health, housing, environment and education.

## Run

Open `civic-ai-prototype.html` in a current browser. The dashboard works without a server, API key, installation, or internet connection. Choose **Residents portal** or **Officers portal** on entry. The queue is saved in that browser's local storage; **Reset sample** restores the synthetic complaints.

Residents see an Instagram-style feed of open complaints, with separate Community spaces for Neighborhood, Transit, Safer Streets, Clean Environment, Health & Care, Homes & Services, and Learning. Spaces filter by selected state and ward. Residents can search, add “I face this too” support, save/share posts, and comment to the responsible department. Complaint entry accepts exact address, name, email, and an optional photo. Sample posts have service-themed illustrations; a photo attached by a resident appears on that post. The glass notification strip surfaces the latest officer update. Location and camera access are requested only after the user taps their controls. Officers select a demo post and department to review reports, update status, and post public replies. Comments stay in a shared resident–department issue thread; there is no resident-to-resident private messaging.

Residents can report a post as spam with a reason. Flags go to the officer review section and do not hide a post automatically. Officers can restore a post, dismiss flags, or hide it after review. The liquid-glass treatment uses browser blur and animation effects; it is an iOS-inspired visual style, not an iOS interface.

The **Use my location** button uses the browser's Geolocation API only after a click. It captures coordinates locally but cannot infer the user's state or ward. The resident must choose a state and ward from the controls. Browser camera access generally requires HTTPS or localhost; the image file picker is an alternative.

## What the demo shows

1. **Understand:** normalize punctuation and spacing; use transparent English and a few romanized Hindi keyword rules to suggest a service; search reports and keep ward details visible.
2. **Prioritize:** apply a simple keyword urgency score and sort reports for human review.
3. **Coordinate:** filter department-specific reports, share status updates, and let neighbors add support to an existing issue.

## Demo limits

- All resident/officer accounts and complaints are fabricated examples.
- Language handling is a few keyword matches, not language detection, translation, transliteration, or multilingual NLP.
- Urgency classification and duplicate matching use simple heuristics. They are not trained or validated models; human review is required.
- Officer selection is not authentication. Department messages, status updates, and support counts are stored only in this browser and are not real notifications.
- Name, email, exact address, GPS coordinates, and optional photo are stored in the browser's local storage for the demo. There is no secure login or access control: the officer/resident switch is only a visual demo. Do not enter real personal information.
- The page does not use IBM LinuxONE, Db2, Snap ML, Telum, or production IBM Z services. Those are possible future architecture choices from the concept, not technologies used here.

For a real pilot, obtain authorized local complaint data and ward boundaries, add verified authentication and role-based access, encrypt and limit retention of contact details and photos, request clear consent, validate predictions with agency staff, and connect an approved case-management and notification system only after review.
